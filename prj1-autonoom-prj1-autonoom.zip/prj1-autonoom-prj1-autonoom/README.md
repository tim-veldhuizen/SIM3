# prj1-autonoom
Hello, welcome to the Project 1 GitHub repo of Loki ing.

We built a 6 sensor line following robot, the sixth sensor is positioned a little bit from the hart of the machine. This robot is specifically designed to drive a course made up of 0 - 135 degree turns a pause symbol made of two horizontal lines with a white space of 14mm. This robot will also stop at a stop symbol.
This robot does not use encoders.

The main code file is located in src>main.cpp

The arduino motorshield rev 3 is used and each side has 2 motors, these motors are connected in series. 

The power is supplied by a 3s lipo battery, this battery is turned down to 8.5v with a dc-dc converter.

The robot is commisioned by Fontys Mechatronica in the Netherlands.

En vergeet niet, Denk Groter!

Groetjes van de hogere jaars ;)


